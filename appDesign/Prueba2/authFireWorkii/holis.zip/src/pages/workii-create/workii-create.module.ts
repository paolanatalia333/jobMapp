import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { WorkiiCreatePage } from './workii-create';

@NgModule({
  declarations: [
    WorkiiCreatePage,
  ],
  imports: [
    IonicPageModule.forChild(WorkiiCreatePage),
  ],
})
export class WorkiiCreatePageModule {}
