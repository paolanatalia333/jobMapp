// Initialize Firebase
export const firebaseConfig = {
    apiKey: "AIzaSyAQhWisp3h7NGxa2TyVTwCfRRmQCw5olAY",
    authDomain: "workiiploy.firebaseapp.com",
    databaseURL: "https://workiiploy.firebaseio.com",
    projectId: "workiiploy",
    storageBucket: "gs://workiiploy.appspot.com",
    messagingSenderId: "1058803298687"
};